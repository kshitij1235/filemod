import setuptools

setuptools.setup(
    name="file_mod",
    version="0.0.2",
    author="kshitij jathar",
    author_email="kshitijjathar7@gmail.com",
    description="This module helps modify the files of various kinds",
    long_description="This module is a easy to use syntax to modify files ",
    url="https://github.com/kshitij1235/filemod",
    project_urls={
        "Bug Tracker": "https://github.com/kshitij1235/filemod/issues",
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ]
)